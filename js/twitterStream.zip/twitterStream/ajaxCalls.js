/**
 * Created by ernani.menezes on 11/11/13.
 */

var ajaxCalls = {
    getMentionsJsonData: "http://vzw.glassfish.w2oservices.com:8080/rest_api_dev/twitter/topic/statuses?tags=verizon&limit=25&min_followers=10&include_replies=false",
    getUsersJsonData: "http://vzw.glassfish.w2oservices.com:8080/rest_api_9/twitter/group/statuses/top?groups=1&period=day&period_count=7&limit=20" 
};