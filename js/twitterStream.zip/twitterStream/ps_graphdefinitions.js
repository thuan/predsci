/*
 *
 * Defines all graphs
 *
 */

(function (ps_graphdefinitions, $, undefined) {

    ps_graphdefinitions.jsonData = "";
    
    ps_graphdefinitions.jsonpData = "";


}(window.ps_graphdefinitions = window.ps_graphdefinitions || {}, jQuery));